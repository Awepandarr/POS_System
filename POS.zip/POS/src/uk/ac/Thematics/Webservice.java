package uk.ac.Thematics;
import static spark.Spark.port;
public class Webservice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		port(8080);
		new BarcodeWebService();
		new InvoiceWebService();
		new OrderWebService();
		new TransactionWebService();
		new PaymentWebService();
		new ProductWebService();
		new EndOfDayReport();
		new CustomerWebService();
		System.out.println("Webservice started on port 8080");
		
		
	}

}
