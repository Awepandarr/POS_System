package uk.ac.Thematics;

public enum PaymentType {
    CARD, CASH;
}
