package uk.ac.Thematics;

import org.json.JSONObject;
import java.math.BigDecimal;
import java.math.BigDecimal;

public class Invoice {
    private int invoiceId;
    private int orderId;
    private String invoiceDate;
    private BigDecimal totalAmount;
    private BigDecimal taxAmount;
    private BigDecimal finalAmount;

    // Constructor
    public Invoice(int invoiceId, int orderId, String invoiceDate, BigDecimal totalAmount, BigDecimal taxAmount, BigDecimal finalAmount) {
        this.invoiceId = invoiceId;
        this.orderId = orderId;
        this.invoiceDate = invoiceDate;
        this.totalAmount = totalAmount;
        this.taxAmount = taxAmount;
        this.finalAmount = finalAmount;
    }

    // Getter methods
    public int getInvoiceId() {
        return invoiceId;
    }

    public int getOrderId() {
        return orderId;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public BigDecimal getTaxAmount() {
        return taxAmount;
    }

    public BigDecimal getFinalAmount() {
        return finalAmount;
    }

    // Setter methods
    public void setInvoiceId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public void setTaxAmount(BigDecimal taxAmount) {
        this.taxAmount = taxAmount;
    }

    public void setFinalAmount(BigDecimal finalAmount) {
        this.finalAmount = finalAmount;
    }

    // Method to convert the Invoice object to JSON (if needed)
    public JSONObject toJSON() {
        JSONObject json = new JSONObject();
        json.put("invoiceId", this.invoiceId);
        json.put("orderId", this.orderId);
        json.put("invoiceDate", this.invoiceDate);
        json.put("totalAmount", this.totalAmount);
        json.put("taxAmount", this.taxAmount);
        json.put("finalAmount", this.finalAmount);
        return json;
    }
}
