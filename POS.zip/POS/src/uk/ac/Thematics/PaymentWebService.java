package uk.ac.Thematics;

import static spark.Spark.*;
import org.json.JSONObject;

public class PaymentWebService {

    public PaymentWebService() {
        // Route to create a payment
        post("/api/payment", (req, res) -> {
            JSONObject requestBody = new JSONObject(req.body());
            Payment payment = new Payment(
                requestBody.getString("transactionId"),
                requestBody.getBigDecimal("amount"),
                PaymentType.valueOf(requestBody.getString("paymentType"))
            );

            boolean success = Database.insertPayment(payment);
            if (success) {
                res.status(201);
                return payment.toJSON().toString();
            } else {
                res.status(400);
                return "Failed to create payment";
            }
        });
    }
}

