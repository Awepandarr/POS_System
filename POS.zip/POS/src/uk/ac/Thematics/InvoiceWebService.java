package uk.ac.Thematics;

import org.json.JSONObject;
import java.math.BigDecimal;
import static spark.Spark.*;

public class InvoiceWebService {

    public InvoiceWebService() {
        
        // Create an invoice
        post("/invoice", (request, response) -> {
            try {
                JSONObject json = new JSONObject(request.body());
                int orderId = json.getInt("orderId");
                int customerId = json.getInt("customerId");
                BigDecimal subtotal = new BigDecimal(json.getString("subtotal"));
                BigDecimal discount = new BigDecimal(json.getString("discount"));
                BigDecimal taxAmount = new BigDecimal(json.getString("taxAmount"));
                BigDecimal serviceCharge = new BigDecimal(json.getString("serviceCharge"));
                BigDecimal finalAmount = new BigDecimal(json.getString("finalAmount"));
                
                // Add invoice date as a string. If needed, replace it with actual date logic.
                String invoiceDate = json.getString("invoiceDate");

                // ✅ Fixed constructor issue
                Invoice invoice = new Invoice(0, orderId, invoiceDate, subtotal.add(discount), taxAmount, finalAmount);
                boolean inserted = Database.insertInvoice(invoice);

                if (inserted) {
                    response.status(201);
                    response.type("application/json");
                    return new JSONObject().put("message", "Invoice created successfully").toString();
                } else {
                    response.status(500);
                    return new JSONObject().put("message", "Error creating invoice").toString();
                }
            } catch (Exception e) {
                e.printStackTrace();
                response.status(400);
                return new JSONObject().put("message", "Invalid input data: " + e.getMessage()).toString();
            }
        });

        // Get an invoice by ID
        get("/invoice/:id", (request, response) -> {
            int invoiceId = Integer.parseInt(request.params(":id"));
            Invoice invoice = Database.getInvoiceByID(invoiceId);

            if (invoice == null) {
                response.status(404);
                return new JSONObject().put("message", "Invoice not found").toString();
            }

            response.type("application/json");
            return invoice.toJSON().toString();
        });
    }
}
