package uk.ac.Thematics;

import org.json.JSONObject;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Payment {
    private int payment_id;
    private int order_id;
    private BigDecimal payment_amount;
    private PaymentType payment_type;
    private PaymentStatus payment_status;
    private LocalDateTime payment_date;
    private String transaction_id;

    // Constructor
    public Payment(String transaction_id, BigDecimal payment_amount, PaymentType payment_type) {
        this.transaction_id = transaction_id;
        this.payment_amount = payment_amount;
        this.payment_type = payment_type;
        this.payment_status = PaymentStatus.PENDING; // Default status
        this.payment_date = LocalDateTime.now(); // Default to current time
    }

    // Getters and Setters
    public int getPaymentId() {
        return payment_id;
    }

    public void setPaymentId(int payment_id) {
        this.payment_id = payment_id;
    }

    public int getOrderId() {
        return order_id;
    }

    public void setOrderId(int order_id) {
        this.order_id = order_id;
    }

    public BigDecimal getPaymentAmount() {
        return payment_amount;
    }

    public void setPaymentAmount(BigDecimal payment_amount) {
        this.payment_amount = payment_amount;
    }

    public PaymentType getPaymentType() {
        return payment_type;
    }

    public void setPaymentType(PaymentType payment_type) {
        this.payment_type = payment_type;
    }

    public PaymentStatus getPaymentStatus() {
        return payment_status;
    }

    public void setPaymentStatus(PaymentStatus payment_status) {
        this.payment_status = payment_status;
    }

    public LocalDateTime getPaymentDate() {
        return payment_date;
    }

    public void setPaymentDate(LocalDateTime payment_date) {
        this.payment_date = payment_date;
    }

    public String getTransactionId() {
        return transaction_id;
    }

    public void setTransactionId(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    // Convert to JSON
    public JSONObject toJSON() {
        JSONObject json = new JSONObject();
        json.put("payment_id", payment_id);
        json.put("order_id", order_id);
        json.put("transaction_id", transaction_id);
        json.put("payment_amount", payment_amount);
        json.put("payment_type", payment_type.toString());
        json.put("payment_status", payment_status.toString());
        json.put("payment_date", payment_date.toString());
        return json;
    }
}
