package uk.ac.Thematics;

import static spark.Spark.*;
import org.json.JSONObject;
import java.math.BigDecimal;

public class OrderWebService {

    public OrderWebService() {
        // Route to get an order by ID
        get("/api/order/:orderId", (req, res) -> {
            int orderId = Integer.parseInt(req.params(":orderId"));
            Order order = Database.getOrderByID(orderId);
            if (order == null) {
                res.status(404);
                return "Order not found";
            }
            res.type("application/json");
            return order.toJSON().toString();
        });

        // Route to create a new order
        post("/api/order", (req, res) -> {
            JSONObject requestBody = new JSONObject(req.body());
            String paymentStatus = requestBody.optString("paymentStatus", "PENDING").toUpperCase();  // Default to "PENDING"
            
            // Ensure that the paymentStatus is valid if it's passed as a string.
            try {
                PaymentStatus status = PaymentStatus.valueOf(paymentStatus);
                
                Order order = new Order(
                    0, // Order ID will be set by the database
                    requestBody.getInt("customerId"),
                    requestBody.getBigDecimal("totalAmount"),
                    status,  // Use the PaymentStatus enum
                    requestBody.getString("orderType"),
                    requestBody.optBigDecimal("taxAmount", BigDecimal.ZERO),
                    requestBody.getBigDecimal("finalAmount"),
                    requestBody.optBigDecimal("discountAmount", BigDecimal.ZERO),
                    requestBody.optString("deliveryType", ""),
                    requestBody.optString("orderStatus", "Pending")
                );

                boolean success = Database.insertOrder(order);
                if (success) {
                    res.status(201);
                    res.type("application/json");
                    return order.toJSON().toString();
                } else {
                    res.status(400);
                    return "Failed to create order";
                }
            } catch (IllegalArgumentException e) {
                res.status(400);
                return "Invalid payment status";
            }
        });

        // Route to update an order
        put("/api/order/:orderId", (req, res) -> {
            JSONObject requestBody = new JSONObject(req.body());
            String paymentStatus = requestBody.optString("paymentStatus", "PENDING").toUpperCase();  // Default to "PENDING"

            try {
                PaymentStatus status = PaymentStatus.valueOf(paymentStatus);

                Order order = new Order(
                    Integer.parseInt(req.params(":orderId")),
                    requestBody.getInt("customerId"),
                    requestBody.getBigDecimal("totalAmount"),
                    status,  // Use the PaymentStatus enum
                    requestBody.getString("orderType"),
                    requestBody.optBigDecimal("taxAmount", BigDecimal.ZERO),
                    requestBody.getBigDecimal("finalAmount"),
                    requestBody.optBigDecimal("discountAmount", BigDecimal.ZERO),
                    requestBody.optString("deliveryType", ""),
                    requestBody.optString("orderStatus", "Pending")
                );

                boolean success = Database.updateOrder(order);
                if (success) {
                    res.status(200);
                    res.type("application/json");
                    return order.toJSON().toString();
                } else {
                    res.status(404);
                    return "Order not found";
                }
            } catch (IllegalArgumentException e) {
                res.status(400);
                return "Invalid payment status";
            }
        });

        // Route to delete an order
        delete("/api/order/:orderId", (req, res) -> {
            int orderId = Integer.parseInt(req.params(":orderId"));
            boolean success = Database.deleteOrderByID(orderId);
            if (success) {
                res.status(200);
                return "Order deleted successfully";
            } else {
                res.status(404);
                return "Order not found";
            }
        });
    }
}
