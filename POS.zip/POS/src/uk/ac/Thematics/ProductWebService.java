package uk.ac.Thematics;

import static spark.Spark.*;
import org.json.JSONObject;

public class ProductWebService {

    public ProductWebService() {
        // Route to get product by barcode
        get("/api/product/:barcode", (req, res) -> {
            String barcode = req.params(":barcode");
            Product product = Database.getProductDetailsByBarcode(barcode);
            if (product == null) {
                res.status(404);
                return "Product not found";
            }
            res.type("application/json");
            return product.toJSON().toString();
        });

        // Route to create a new product
        post("/api/product", (req, res) -> {
            JSONObject requestBody = new JSONObject(req.body());
            Product product = new Product(
                0, // Will be set by the database
                requestBody.getString("name"),
                requestBody.getBigDecimal("price"),
                requestBody.getInt("categoryId"),
                requestBody.getInt("stockQuantity"),
                requestBody.getString("barcode")
            );

            boolean success = Database.insertProduct(product);
            if (success) {
                res.status(201);
                res.type("application/json");
                return product.toJSON().toString();
            } else {
                res.status(400);
                return "Failed to create product";
            }
        });

        // Route to update an existing product
        put("/api/product/:productId", (req, res) -> {
            JSONObject requestBody = new JSONObject(req.body());
            Product product = new Product(
                Integer.parseInt(req.params(":productId")),
                requestBody.getString("name"),
                requestBody.getBigDecimal("price"),
                requestBody.getInt("categoryId"),
                requestBody.getInt("stockQuantity"),
                requestBody.getString("barcode")
            );

            boolean success = Database.updateProduct(product);
            if (success) {
                res.status(200);
                res.type("application/json");
                return product.toJSON().toString();
            } else {
                res.status(404);
                return "Product not found";
            }
        });

        // Route to delete a product by ID
        delete("/api/product/:productId", (req, res) -> {
            int productId = Integer.parseInt(req.params(":productId"));
            boolean success = Database.deleteProductByID(productId);
            if (success) {
                res.status(200);
                return "Product deleted successfully";
            } else {
                res.status(404);
                return "Product not found";
            }
        });

        // Route to get product by ID
        get("/api/product/id/:productId", (req, res) -> {
            int productId = Integer.parseInt(req.params(":productId"));
            Product product = Database.getProductByID(productId);
            if (product == null) {
                res.status(404);
                return "Product not found";
            }
            res.type("application/json");
            return product.toJSON().toString();
        });
    }
}

