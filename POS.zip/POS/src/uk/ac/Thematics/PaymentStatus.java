package uk.ac.Thematics;

public enum PaymentStatus {
    PENDING, PAID, CANCELLED, FAILED;
}
