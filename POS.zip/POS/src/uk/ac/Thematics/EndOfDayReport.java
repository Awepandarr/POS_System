package uk.ac.Thematics;

import java.math.BigDecimal;
import static spark.Spark.*;
import org.json.JSONObject;

public class EndOfDayReport {

    public EndOfDayReport() {

        // Generate End of Day Report
        get("/endOfDayReport", (request, response) -> {
            JSONObject report = generateEndOfDayReport();
            response.type("application/json");
            return report.toString();
        });
    }

    // Method to generate End of Day report
    public static JSONObject generateEndOfDayReport() {
        // You can adjust this query to match your database schema

        JSONObject report = new JSONObject();
        
        try {
            BigDecimal totalSales = Database.getTotalSalesForTheDay();
            BigDecimal totalPayments = Database.getTotalPaymentsForTheDay();
            BigDecimal totalDiscounts = Database.getTotalDiscountsForTheDay();
            String paymentBreakdown = Database.getPaymentBreakdownForTheDay();  // A string like "Cash: 500, Card: 900"

            report.put("total_sales", totalSales);
            report.put("total_payments", totalPayments);
            report.put("total_discounts", totalDiscounts);
            report.put("payment_breakdown", paymentBreakdown);

        } catch (Exception e) {
            // Handle error if something goes wrong
            report.put("error", "Failed to generate report: " + e.getMessage());
        }

        return report;
    }
}
