package uk.ac.Thematics;

import java.sql.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

public class Database {

    private static final String JDBC_CONNECTION_STRING = "jdbc:sqlite:POS.db";
    private static Connection connection = null;

    private Database() {} // Private constructor to prevent instantiation

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(JDBC_CONNECTION_STRING);
                System.out.println("Connected to the database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Database connection failed!");
        }
        return connection;
    }

    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Insert Product
    public static boolean insertProduct(Product product) {
        String query = "INSERT INTO Products (name, price, category_id, stock_quantity, barcode) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, product.getName());
            ps.setBigDecimal(2, product.getPrice());
            ps.setInt(3, product.getCategoryId());
            ps.setInt(4, product.getStockQuantity());
            ps.setString(5, product.getBarcode());

            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        product.setProductId(rs.getInt(1));  // Set the generated product ID
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Get Product by Barcode
 // Get Product by Barcode
    public static Product getProductDetailsByBarcode(String barcode) {
        String query = "SELECT * FROM Products WHERE barcode = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, barcode);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Mapping result to Product object
                    return new Product(
                        rs.getInt("product_id"),
                        rs.getString("name"),
                        rs.getBigDecimal("price"),
                        rs.getInt("category_id"),
                        rs.getInt("stock_quantity"),
                        rs.getString("barcode")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Product not found
    }


    // Get Product by ID
    public static Product getProductByID(int productID) {
        String query = "SELECT * FROM Products WHERE product_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, productID);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Product(
                        rs.getInt("product_id"),
                        rs.getString("name"),
                        rs.getBigDecimal("price"),
                        rs.getInt("category_id"),
                        rs.getInt("stock_quantity"),
                        rs.getString("barcode")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update Product
    public static boolean updateProduct(Product product) {
        String query = "UPDATE Products SET name = ?, price = ?, stock_quantity = ? WHERE product_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, product.getName());
            ps.setBigDecimal(2, product.getPrice());
            ps.setInt(3, product.getStockQuantity());
            ps.setInt(4, product.getProductId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete Product by ID
    public static boolean deleteProductByID(int productId) {
        String query = "DELETE FROM Products WHERE product_id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setInt(1, productId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Insert Order
    public static boolean insertOrder(Order order) {
        String query = "INSERT INTO Orders (customer_id, total_amount, payment_status, order_type, tax_amount, final_amount, discount_amount, delivery_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, order.getCustomerId());
            ps.setBigDecimal(2, order.getTotalAmount());
            ps.setString(3, order.getPaymentStatus().toString());
            ps.setString(4, order.getOrderType());
            ps.setBigDecimal(5, order.getTaxAmount());
            ps.setBigDecimal(6, order.getFinalAmount());
            ps.setBigDecimal(7, order.getDiscountAmount());
            ps.setString(8, order.getDeliveryType());

            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        order.setOrderId(rs.getInt(1));  // Set the generated order ID
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update Order
    public static boolean updateOrder(Order order) {
        String query = "UPDATE Orders SET customer_id = ?, total_amount = ?, payment_status = ?, order_type = ?, tax_amount = ?, final_amount = ?, discount_amount = ?, delivery_type = ? WHERE order_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, order.getCustomerId());
            ps.setBigDecimal(2, order.getTotalAmount());
            ps.setString(3, order.getPaymentStatus().toString());
            ps.setString(4, order.getOrderType());
            ps.setBigDecimal(5, order.getTaxAmount());
            ps.setBigDecimal(6, order.getFinalAmount());
            ps.setBigDecimal(7, order.getDiscountAmount());
            ps.setString(8, order.getDeliveryType());
            ps.setInt(9, order.getOrderId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete Order by ID
    public static boolean deleteOrderByID(int orderId) {
        String query = "DELETE FROM Orders WHERE order_id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setInt(1, orderId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Insert Order Item
    public static boolean insertOrderItem(OrderItem orderItem) {
        String query = "INSERT INTO Order_Items (order_id, product_id, quantity, price, subtotal) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, orderItem.getOrderId());
            ps.setInt(2, orderItem.getProductId());
            ps.setInt(3, orderItem.getQuantity());
            ps.setBigDecimal(4, orderItem.getPrice());
            ps.setBigDecimal(5, orderItem.getSubtotal());

            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        orderItem.setOrderItemId(rs.getInt(1));  // Set the generated order item ID
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete Order Item by ID
    public static boolean deleteOrderItemByID(int orderItemId) {
        String query = "DELETE FROM Order_Items WHERE order_item_id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setInt(1, orderItemId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public static boolean insertInvoice(Invoice invoice) {
        String query = "INSERT INTO Invoices (order_id, invoice_date, total_amount, tax_amount, final_amount) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, invoice.getOrderId());
            ps.setString(2, invoice.getInvoiceDate());
            ps.setBigDecimal(3, invoice.getTotalAmount());
            ps.setBigDecimal(4, invoice.getTaxAmount());
            ps.setBigDecimal(5, invoice.getFinalAmount());

            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        invoice.setInvoiceId(rs.getInt(1)); // Set generated ID
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            // Log the exception details for debugging
            e.printStackTrace();
        }
        
        return false; // Return false if no rows were affected or an error occurred
    }


    // Get Invoice by ID
    public static Invoice getInvoiceByID(int invoiceId) {
        String query = "SELECT * FROM Invoices WHERE invoice_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, invoiceId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Invoice(
                        rs.getInt("invoice_id"),
                        rs.getInt("order_id"),
                        rs.getString("invoice_date"),
                        rs.getBigDecimal("total_amount"),
                        rs.getBigDecimal("tax_amount"),
                        rs.getBigDecimal("final_amount")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    // Insert Transaction
    public static boolean insertTransaction(Transaction transaction) {
        String query = "INSERT INTO Transactions (transaction_id, order_id, total_amount, payment_method, transaction_date, payment_status) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, transaction.getTransactionID());
            ps.setString(2, transaction.getOrderID());
            ps.setBigDecimal(3, transaction.getTotalAmount());
            ps.setString(4, transaction.getPaymentMethod());
            ps.setString(5, transaction.getTransactionDate());
            ps.setString(6, transaction.getPaymentStatus().toString());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Insert failed
    }

    // Delete Transaction by ID
    public static boolean deleteTransactionByID(String transactionID) {
        String query = "DELETE FROM Transactions WHERE transaction_id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setString(1, transactionID);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Insert Payment
    public static boolean insertPayment(Payment payment) {
        String query = "INSERT INTO Payments (transaction_id, amount, payment_type) VALUES (?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, payment.getTransactionId());
            ps.setBigDecimal(2, payment.getPaymentAmount());
            ps.setString(3, payment.getPaymentType().toString());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Insert failed
    }

    // Delete Payment by Transaction ID
    public static boolean deletePaymentByTransactionID(String transactionID) {
        String query = "DELETE FROM Payments WHERE transaction_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, transactionID);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Deletion failed
    }

    // Update Transaction
    public static boolean updateTransaction(Transaction transaction) {
        String query = "UPDATE Transactions SET order_id = ?, total_amount = ?, payment_method = ?, transaction_date = ?, payment_status = ? WHERE transaction_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, transaction.getOrderID());
            ps.setBigDecimal(2, transaction.getTotalAmount());
            ps.setString(3, transaction.getPaymentMethod());
            ps.setString(4, transaction.getTransactionDate());
            ps.setString(5, transaction.getPaymentStatus().toString());
            ps.setString(6, transaction.getTransactionID());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update Payment
    public static boolean updatePayment(Payment payment) {
        String query = "UPDATE Payments SET amount = ?, payment_type = ? WHERE transaction_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setBigDecimal(1, payment.getPaymentAmount());
            ps.setString(2, payment.getPaymentType().toString());
            ps.setString(3, payment.getTransactionId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public static BigDecimal getTotalSalesForTheDay() throws SQLException {
        String query = "SELECT SUM(final_amount) FROM Orders WHERE order_date = CURDATE()";
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                return rs.getBigDecimal(1);  // Return the total sales amount
            }
        }
        return BigDecimal.ZERO;
    }
    public static BigDecimal getTotalPaymentsForTheDay() throws SQLException {
        String query = "SELECT SUM(payment_amount) FROM Payments WHERE payment_date = CURDATE()";
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                return rs.getBigDecimal(1);  // Return the total payments amount
            }
        }
        return BigDecimal.ZERO;
    }
    public static BigDecimal getTotalDiscountsForTheDay() throws SQLException {
        String query = "SELECT SUM(discount_amount) FROM Orders WHERE order_date = CURDATE()";
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                return rs.getBigDecimal(1);  // Return the total discount amount
            }
        }
        return BigDecimal.ZERO;
    }
    public static boolean insertCustomer(Customer customer) {
        String query = "INSERT INTO Customers (customer_name, customer_email, contact, loyalty_points) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, customer.getCustomerName());
            stmt.setString(2, customer.getCustomerEmail());
            stmt.setString(3, customer.getContact());
            stmt.setInt(4, customer.getLoyaltyPoints());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Customer getCustomerByID(int customerId) {
        String query = "SELECT * FROM Customers WHERE customer_id = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Customer(
                    rs.getInt("customer_id"),
                    rs.getString("customer_name"),
                    rs.getString("customer_email"),
                    rs.getString("contact"),
                    null,  // Provide null for address
                    rs.getInt("loyalty_points")
                );
            } else {
                System.out.println("Customer with ID " + customerId + " not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    public static boolean updateCustomer(Customer customer) {
        String query = "UPDATE Customers SET customer_name = ?, customer_email = ?, contact = ?, loyalty_points = ? WHERE customer_id = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, customer.getCustomerName());
            stmt.setString(2, customer.getCustomerEmail());
            stmt.setString(3, customer.getContact());
            stmt.setInt(4, customer.getLoyaltyPoints());
            stmt.setInt(5, customer.getCustomerId());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteCustomerByID(int customerId) {
        String query = "DELETE FROM Customers WHERE customer_id = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public static String getPaymentBreakdownForTheDay() throws SQLException {
        String query = "SELECT payment_method, SUM(payment_amount) FROM Payments WHERE payment_date = CURDATE() GROUP BY payment_method";
        StringBuilder breakdown = new StringBuilder();

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String paymentMethod = rs.getString("payment_method");
                BigDecimal amount = rs.getBigDecimal("SUM(payment_amount)");
                breakdown.append(paymentMethod).append(": ").append(amount).append(", ");
            }
        }

        // Remove the last comma and space if there is any
        if (breakdown.length() > 0) {
            breakdown.setLength(breakdown.length() - 2);
        }
        
        return breakdown.toString();
    }
    // Get Order by ID
    public static Order getOrderByID(int orderId) {
        String query = "SELECT * FROM Orders WHERE order_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Order(
                        rs.getInt("order_id"),
                        rs.getInt("customer_id"),
                        rs.getBigDecimal("total_amount"),
                        PaymentStatus.valueOf(rs.getString("payment_status")),
                        rs.getString("order_type"),
                        rs.getBigDecimal("tax_amount"),
                        rs.getBigDecimal("final_amount"),
                        rs.getBigDecimal("discount_amount"),
                        rs.getString("delivery_type"),
                        rs.getString("order_status")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Get Transaction by ID
    public static Transaction getTransactionByID(String transactionID) {
        String query = "SELECT * FROM Transactions WHERE transaction_id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setString(1, transactionID);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return new Transaction(
                    rs.getString("transaction_id"),
                    rs.getString("order_id"),
                    rs.getBigDecimal("total_amount"),
                    rs.getString("payment_method"),
                    rs.getString("transaction_date"),
                    PaymentStatus.valueOf(rs.getString("payment_status"))
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Transaction not found
    }

    // Get Payment by Transaction ID
    public static Payment getPaymentByTransactionID(String transactionID) {
        String query = "SELECT * FROM Payments WHERE transaction_id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, transactionID);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Payment(
                    rs.getString("transaction_id"),
                    rs.getBigDecimal("amount"),
                    PaymentType.valueOf(rs.getString("payment_type"))
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Payment not found
    }

    // Get Order Item by ID
    public static OrderItem getOrderItemByID(int orderItemId) {
        String query = "SELECT * FROM Order_Items WHERE order_item_id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, orderItemId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new OrderItem(
                    rs.getInt("order_item_id"),
                    rs.getInt("order_id"),
                    rs.getInt("product_id"),
                    rs.getInt("quantity"),
                    rs.getBigDecimal("price"),
                    rs.getBigDecimal("subtotal")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Order item not found
    }

    // Get Order Items by Order ID
    public static List<OrderItem> getOrderItemsByOrderID(int orderId) {
        List<OrderItem> orderItems = new ArrayList<>();
        String query = "SELECT * FROM Order_Items WHERE order_id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, orderId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                orderItems.add(new OrderItem(
                    rs.getInt("order_item_id"),
                    rs.getInt("order_id"),
                    rs.getInt("product_id"),
                    rs.getInt("quantity"),
                    rs.getBigDecimal("price"),
                    rs.getBigDecimal("subtotal")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderItems;
    }
}
